<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $product->name }} - E-commerce</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    @include('partials.navbar')
    <header>
        <h1>{{ $product->name }}</h1>
        <a href="{{ route('categories.show', $product->category->id) }}">Retour à la catégorie</a>
    </header>
    <section>
        <h2>Détails du Produit</h2>
        <p><strong>Description :</strong> {{ $product->description }}</p>
        <p><strong>Prix :</strong> {{ $product->price }} €</p>
        <p><img src="{{ asset('images/' . $product->image) }}" alt="{{ $product->name }}"></p>
        <!-- Ajouter ici la possibilité d'ajouter au panier -->
    </section>
</body>
</html>
