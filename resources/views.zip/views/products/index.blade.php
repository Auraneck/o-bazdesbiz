<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produits - E-commerce</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    @include('partials.navbar')
    <header>
        <h1>Tous les Produits</h1>
    </header>
    <section>
        @foreach($categories as $category)
            <h2>{{ $category->name }}</h2>
            <ul>
                @foreach($category->products as $product)
                    <li>
                        <a href="{{ route('products.show', $product->id) }}">{{ $product->name }}</a> - {{ $product->price }} €
                    </li>
                @endforeach
            </ul>
        @endforeach
    </section>
</body>
</html>
