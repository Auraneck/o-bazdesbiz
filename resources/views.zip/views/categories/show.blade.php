<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $category->name }} - E-commerce</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    @include('partials.navbar')
    <header>
        <h1>{{ $category->name }}</h1>
        <a href="{{ route('home') }}">Retour à l'accueil</a>
    </header>
    <section>
        <h2>Produits dans la catégorie {{ $category->name }}</h2>
        <ul>
            @foreach($category->products as $product)
                <li>
                    <a href="{{ route('products.show', $product->id) }}">{{ $product->name }}</a> - {{ $product->price }} €
                </li>
            @endforeach
        </ul>
    </section>
</body>
</html>
