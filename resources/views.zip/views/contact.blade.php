<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - E-commerce</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    @include('partials.navbar')
    <header>
        <h1>Contactez-nous</h1>
    </header>
    <section>
        <p>Formulaire de contact à venir.</p>
    </section>
</body>
</html>
