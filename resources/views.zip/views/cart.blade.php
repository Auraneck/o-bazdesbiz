<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier - E-commerce</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    @include('partials.navbar')
    <header>
        <h1>Votre Panier</h1>
    </header>
    <section>
        <p>Panier vide pour l'instant.</p>
    </section>
</body>
</html>
