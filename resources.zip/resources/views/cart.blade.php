@extends('layouts.app')

@section('title', 'Panier')

@section('content')
<header>
    <h1>Votre Panier</h1>
</header>
<section class="mt-4">
    <p>Panier vide pour l'instant.</p>
    <a href="{{ route('products.index') }}" class="btn btn-primary">Continuer vos achats</a>
</section>
@endsection
